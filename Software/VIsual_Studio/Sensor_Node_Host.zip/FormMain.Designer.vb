﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.ButtonOpen = New System.Windows.Forms.Button()
        Me.ButtonQuit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LabelSensorA = New System.Windows.Forms.Label()
        Me.LabelSensorB = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.StatusStripLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStripLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ComboBoxComPort = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ButtonStart = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LabelSensorC = New System.Windows.Forms.Label()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SerialPort1
        '
        '
        'ButtonOpen
        '
        Me.ButtonOpen.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonOpen.Location = New System.Drawing.Point(28, 108)
        Me.ButtonOpen.Name = "ButtonOpen"
        Me.ButtonOpen.Size = New System.Drawing.Size(96, 45)
        Me.ButtonOpen.TabIndex = 0
        Me.ButtonOpen.Text = "&Open"
        Me.ButtonOpen.UseVisualStyleBackColor = True
        '
        'ButtonQuit
        '
        Me.ButtonQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte), True)
        Me.ButtonQuit.Location = New System.Drawing.Point(333, 32)
        Me.ButtonQuit.Name = "ButtonQuit"
        Me.ButtonQuit.Size = New System.Drawing.Size(75, 45)
        Me.ButtonQuit.TabIndex = 1
        Me.ButtonQuit.Text = "&Quit"
        Me.ButtonQuit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(161, 129)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(139, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = " Sensor A (mV)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(167, 193)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 24)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Sensor B (mV)"
        '
        'LabelSensorA
        '
        Me.LabelSensorA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelSensorA.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSensorA.Location = New System.Drawing.Point(331, 129)
        Me.LabelSensorA.Name = "LabelSensorA"
        Me.LabelSensorA.Size = New System.Drawing.Size(77, 29)
        Me.LabelSensorA.TabIndex = 4
        '
        'LabelSensorB
        '
        Me.LabelSensorB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelSensorB.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSensorB.Location = New System.Drawing.Point(331, 188)
        Me.LabelSensorB.Name = "LabelSensorB"
        Me.LabelSensorB.Size = New System.Drawing.Size(77, 29)
        Me.LabelSensorB.TabIndex = 5
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusStripLabel1, Me.StatusStripLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 324)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(434, 22)
        Me.StatusStrip1.TabIndex = 6
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusStripLabel1
        '
        Me.StatusStripLabel1.Name = "StatusStripLabel1"
        Me.StatusStripLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'StatusStripLabel2
        '
        Me.StatusStripLabel2.Name = "StatusStripLabel2"
        Me.StatusStripLabel2.Size = New System.Drawing.Size(0, 17)
        '
        'ComboBoxComPort
        '
        Me.ComboBoxComPort.FormattingEnabled = True
        Me.ComboBoxComPort.Location = New System.Drawing.Point(28, 56)
        Me.ComboBoxComPort.Name = "ComboBoxComPort"
        Me.ComboBoxComPort.Size = New System.Drawing.Size(94, 21)
        Me.ComboBoxComPort.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(25, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(141, 20)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Choose Serial Port"
        '
        'ButtonStart
        '
        Me.ButtonStart.Enabled = False
        Me.ButtonStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonStart.Location = New System.Drawing.Point(29, 173)
        Me.ButtonStart.Name = "ButtonStart"
        Me.ButtonStart.Size = New System.Drawing.Size(98, 49)
        Me.ButtonStart.TabIndex = 9
        Me.ButtonStart.Text = "Start"
        Me.ButtonStart.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(167, 252)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(134, 24)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Sensor C (mV)"
        '
        'LabelSensorC
        '
        Me.LabelSensorC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelSensorC.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSensorC.Location = New System.Drawing.Point(331, 252)
        Me.LabelSensorC.Name = "LabelSensorC"
        Me.LabelSensorC.Size = New System.Drawing.Size(77, 29)
        Me.LabelSensorC.TabIndex = 11
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(434, 346)
        Me.Controls.Add(Me.LabelSensorC)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ButtonStart)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ComboBoxComPort)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.LabelSensorB)
        Me.Controls.Add(Me.LabelSensorA)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ButtonQuit)
        Me.Controls.Add(Me.ButtonOpen)
        Me.Name = "FormMain"
        Me.Text = "Sensor Node Demo"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents ButtonOpen As Button
    Friend WithEvents ButtonQuit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents LabelSensorA As Label
    Friend WithEvents LabelSensorB As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ComboBoxComPort As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents StatusStripLabel1 As ToolStripStatusLabel
    Friend WithEvents StatusStripLabel2 As ToolStripStatusLabel
    Friend WithEvents ButtonStart As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents LabelSensorC As Label
End Class
