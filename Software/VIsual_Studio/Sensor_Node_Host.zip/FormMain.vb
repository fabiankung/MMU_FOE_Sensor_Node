﻿Public Class FormMain

    'Global public datatypes declaration 
    Public Const mstrSoftwareTitle = "Demo"
    Public Const mstrSoftwareVersion = "Version 0.11"
    Public Const mstrSoftwareAuthor = "FK"
    Public Const mstrSoftwareDate = "8 June 2022"
    Public Const mstrCompany = "Multimedia University"
    Public Const mstrAddress = "Faculty of Engineering, Jalan Multimedia, Cyberjaya, Selangor, MALAYSIA"
    Public Const mstrWebpage = "http://foe.mmu.edu.my"

    'Global private variables declaration 
    Private Const cintTimerInterval = 10 'Timer clock tick interval in msec.

    Private bytReceiveData As Byte
    Private bytSendData As Byte
    Private mstrComPortName As String
    Private bytSlaveID As Byte

    Private mbytRxData(0 To 32) As Byte

    'Global public variable declaration
    Public gnDataReceiveFlag As Integer '0 = No data, 1 = New data.
    Public gnSerialReceiveThreshold As Integer 'Received bytes trigger threshold.



    Private Sub ButtonOpen_Click(sender As Object, e As EventArgs) Handles ButtonOpen.Click
        Try

            If SerialPort1.IsOpen = False Then 'Check if Serial Port is opened, if not open the port.
                SerialPort1.PortName = mstrComPortName 'Set the COM port name.

                SerialPort1.BaudRate = 115200
                SerialPort1.Parity = IO.Ports.Parity.None
                SerialPort1.StopBits = IO.Ports.StopBits.One
                SerialPort1.DataBits = 8
                SerialPort1.Handshake = IO.Ports.Handshake.None
                SerialPort1.ReceivedBytesThreshold = 6 'Only generate a system interrupt when multiple of 6 bytes are received in the receive buffer.
                'Need to ensure that data from remote unit is in multiples of 8 bytes.        

                SerialPort1.Open()

                SerialPort1.DiscardInBuffer() 'Flush buffer after initialization.
                gnDataReceiveFlag = 0 'Clear flag.
                gnSerialReceiveThreshold = 6 'Default packet length.

                If SerialPort1.IsOpen = True Then   'Change the status of the Open Button once the Serial Port is opened.
                    ButtonOpen.Text = "CLOSE"
                    StatusStripLabel1.Text = mstrComPortName & " is opened"

                    'Enable all relevant controls.
                    ButtonStart.Enabled = True


                End If

            Else 'Serial port is already opened.

                SerialPort1.Close() 'Close the Serial Port.
                StatusStripLabel1.Text = "No COM port open"
                ButtonOpen.Text = "OPEN"
                'Disable all relevant controls.
                ButtonStart.Enabled = False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Open Error!", MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim nPortCount As Integer

        Try

            Me.Text = mstrSoftwareTitle & " " & mstrSoftwareVersion & " (" & mstrSoftwareDate & ")"

            'Initialize all module level parameters.
            gnDataReceiveFlag = 0
            Timer1.Interval = cintTimerInterval 'Load timer interval in miliseconds.
            Timer1.Enabled = True 'Enable timer.

            'intSpeed = 3 'The default speed.
            bytSlaveID = 1 'The default remote device ID.
            StatusStripLabel1.Text = "No COM port open"

            'List all available serial port in the Combobox items and initialize the selection.
            For Each strSerialPortName As String In My.Computer.Ports.SerialPortNames
                ComboBoxComPort.Items.Add(strSerialPortName)
                nPortCount += 1
            Next
            If nPortCount = 0 Then 'Check if serial port exist.
                MessageBox.Show("No serial port found, please setup a serial port", "ERROR", MessageBoxButtons.OK)
            Else
                mstrComPortName = ComboBoxComPort.Items(0) 'The default COM Port name.
                ComboBoxComPort.SelectedIndex = 0
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub ComboBoxComPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxComPort.SelectedIndexChanged

        mstrComPortName = ComboBoxComPort.Items(ComboBoxComPort.SelectedIndex)    'Update the name of the selected COM Port, i.e. "COMX", where X = 1,2,3...

    End Sub

    Private Sub SerialPort1_ErrorReceived(sender As Object, e As IO.Ports.SerialErrorReceivedEventArgs) Handles SerialPort1.ErrorReceived

        SerialPort1.DiscardInBuffer() 'Flush buffer to prepare for incoming data.
        StatusStripLabel1.Text = "Serial Port Error!"

    End Sub

    'Subroutine to monitor the input bufffer of the virtual UART port.  Trigger the system if minimum number of bytes are received.
    Private Sub SerialPort1_DataReceived(sender As Object, e As IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived

        If (SerialPort1.BytesToRead >= gnSerialReceiveThreshold) Then  'The receive data packet larger than the threshold?.
            gnDataReceiveFlag = 1   'Assert data receive flag.
            SerialPort1.Read(mbytRxData, 0, 6) 'Read 6 bytes of data from serial port receive buffer.
            SerialPort1.DiscardInBuffer() 'Flush buffer
        End If

    End Sub

    Private Sub FormMain_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed

        If SerialPort1.IsOpen = True Then
            SerialPort1.Close()
        End If

    End Sub

    Private Sub ButtonQuit_Click(sender As Object, e As EventArgs) Handles ButtonQuit.Click
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Static Dim intCount As Integer
        Dim strRxData As String

        If SerialPort1.IsOpen = True Then 'Only proceed if serial port is opened.
            'Blink an indicator (the word "BT") on the main window status.
            intCount = intCount + 1
            If (intCount > 31) Then                     'Check if counter overflows.
                intCount = 0                            'Reset counter
                If StatusStripLabel1.Text = "" Then
                    StatusStripLabel1.Text = "C"       'Show the word "C".
                Else
                    StatusStripLabel1.Text = ""         'Empty the status.
                End If
            End If
        End If

        'Check for data packet received from TX units.
        If gnDataReceiveFlag = 1 Then
            gnDataReceiveFlag = 0                       'Deassert data receive flag.
            strRxData = ""                              'Clear string 1st.
            strRxData = strRxData & ChrW(mbytRxData(0)) 'Form a string from each character.
            strRxData = strRxData & ChrW(mbytRxData(1))
            strRxData = strRxData & ChrW(mbytRxData(2))
            strRxData = strRxData & ChrW(mbytRxData(3))
            strRxData = strRxData & ChrW(mbytRxData(4))
            strRxData = strRxData & ChrW(mbytRxData(5))

            If mbytRxData(1) = 65 Then  'Compare with character 'A'
                LabelSensorA.Text = strRxData
            ElseIf mbytRxData(1) = 66 Then 'Compare with character 'B'
                LabelSensorB.Text = strRxData
            ElseIf mbytRxData(1) = 67 Then 'Compare with character 'C'
                LabelSensorC.Text = strRxData
            End If

        End If
    End Sub

    Private Sub ButtonStart_Click(sender As Object, e As EventArgs) Handles ButtonStart.Click
        Dim bytTxData(0 To 7) As Byte

        If SerialPort1.IsOpen = True Then       'Only proceed if serial port is opened.
            SerialPort1.DiscardInBuffer()       'Flush buffer 1st before sending out any data.
            bytTxData(0) = CByte(AscW("s"))     'ASCII instruction 's', Start command
            SerialPort1.Write(bytTxData, 0, 1)  'Write 1 bytes of data to serial port.
        Else
            MessageBox.Show("Please open a COM port first", "ERROR", MessageBoxButtons.OK)
        End If
    End Sub
End Class
